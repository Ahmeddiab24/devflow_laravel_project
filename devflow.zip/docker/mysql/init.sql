-- DevFlow MySQL Init Script
-- Runs once on first container start

-- Create test database for CI/CD pipeline
CREATE DATABASE IF NOT EXISTS devflow_test
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

GRANT ALL PRIVILEGES ON devflow_test.* TO 'devflow'@'%';
FLUSH PRIVILEGES;
